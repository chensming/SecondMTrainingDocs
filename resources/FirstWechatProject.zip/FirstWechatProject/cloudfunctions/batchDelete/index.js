// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database();

// 云函数入口函数
exports.main = async(event, context) => {
  try {
    
    //需要你删除并返回结果，提示，调用where查找后再调用remove方法
  } catch (e) {
    console.error(e);
  }
}