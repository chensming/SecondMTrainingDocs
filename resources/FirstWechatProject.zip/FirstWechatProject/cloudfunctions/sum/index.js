// 云函数入口函数
exports.main = async (event, context) => {
  return {
    //将注释去掉
    // sum: event.a + event.b
  }
}